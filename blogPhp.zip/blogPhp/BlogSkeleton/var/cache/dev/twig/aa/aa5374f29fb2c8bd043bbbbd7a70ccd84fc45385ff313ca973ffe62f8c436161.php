<?php

/* blog/index.html.twig */
class __TwigTemplate_327697e25e608b9efad403c2b9ddb5ce302be5f361ba877e6ac2bb414a3babb7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4bca97f967d84af8737c4b277798b9a5b4c2b87446d789a3ad7510acc89c0b59 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bca97f967d84af8737c4b277798b9a5b4c2b87446d789a3ad7510acc89c0b59->enter($__internal_4bca97f967d84af8737c4b277798b9a5b4c2b87446d789a3ad7510acc89c0b59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4bca97f967d84af8737c4b277798b9a5b4c2b87446d789a3ad7510acc89c0b59->leave($__internal_4bca97f967d84af8737c4b277798b9a5b4c2b87446d789a3ad7510acc89c0b59_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_757eb5c325d4abeb89e94269e98d6d171273292f1d2b9526da3f94f1269a4266 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_757eb5c325d4abeb89e94269e98d6d171273292f1d2b9526da3f94f1269a4266->enter($__internal_757eb5c325d4abeb89e94269e98d6d171273292f1d2b9526da3f94f1269a4266_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "
";
        
        $__internal_757eb5c325d4abeb89e94269e98d6d171273292f1d2b9526da3f94f1269a4266->leave($__internal_757eb5c325d4abeb89e94269e98d6d171273292f1d2b9526da3f94f1269a4266_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block main %}

{% endblock %}
";
    }
}
