<?php

/* user/profile.html.twig */
class __TwigTemplate_c54ae30d53b2d4e9e49c792bd8ef68c5b80357704c2d9325c65d9d55399d9b89 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/profile.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb6ae6c9a0ac10dbb392734dd31b2b6f05ffcddf99f91619c1d69c11b489d267 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eb6ae6c9a0ac10dbb392734dd31b2b6f05ffcddf99f91619c1d69c11b489d267->enter($__internal_eb6ae6c9a0ac10dbb392734dd31b2b6f05ffcddf99f91619c1d69c11b489d267_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/profile.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eb6ae6c9a0ac10dbb392734dd31b2b6f05ffcddf99f91619c1d69c11b489d267->leave($__internal_eb6ae6c9a0ac10dbb392734dd31b2b6f05ffcddf99f91619c1d69c11b489d267_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_1974c33136ec1983dbaca438523ef54b81db1f3eb2417d73daafcdebd14faf2c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1974c33136ec1983dbaca438523ef54b81db1f3eb2417d73daafcdebd14faf2c->enter($__internal_1974c33136ec1983dbaca438523ef54b81db1f3eb2417d73daafcdebd14faf2c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "profile";
        
        $__internal_1974c33136ec1983dbaca438523ef54b81db1f3eb2417d73daafcdebd14faf2c->leave($__internal_1974c33136ec1983dbaca438523ef54b81db1f3eb2417d73daafcdebd14faf2c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_c1c9bc1b934ecfcecf7f9d73dd668e28addb30da7bec97613711df16e9ea5486 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c1c9bc1b934ecfcecf7f9d73dd668e28addb30da7bec97613711df16e9ea5486->enter($__internal_c1c9bc1b934ecfcecf7f9d73dd668e28addb30da7bec97613711df16e9ea5486_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <div>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "email", array()), "html", null, true);
        echo "
        <br>
        ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "fullName", array()), "html", null, true);
        echo "
    </div>
";
        
        $__internal_c1c9bc1b934ecfcecf7f9d73dd668e28addb30da7bec97613711df16e9ea5486->leave($__internal_c1c9bc1b934ecfcecf7f9d73dd668e28addb30da7bec97613711df16e9ea5486_prof);

    }

    public function getTemplateName()
    {
        return "user/profile.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  61 => 9,  56 => 7,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends 'base.html.twig' %}

{% block body_id 'profile' %}

{% block main %}
    <div>
        {{ user.email }}
        <br>
        {{ user.fullName }}
    </div>
{% endblock %}
";
    }
}
