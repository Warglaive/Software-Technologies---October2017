<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_b8960e73b9ac758da0b7b9b7e77d53d191142c962f2e8b2544004f6e2f215c2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb187e5fefcad08b950df0221799fc96bc610d8ad08cff9af2fb52709e874530 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fb187e5fefcad08b950df0221799fc96bc610d8ad08cff9af2fb52709e874530->enter($__internal_fb187e5fefcad08b950df0221799fc96bc610d8ad08cff9af2fb52709e874530_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fb187e5fefcad08b950df0221799fc96bc610d8ad08cff9af2fb52709e874530->leave($__internal_fb187e5fefcad08b950df0221799fc96bc610d8ad08cff9af2fb52709e874530_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_2d431b4aa906ffd611b197fa06623c407b256f0f83ee011f83d42b0ec405ca58 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2d431b4aa906ffd611b197fa06623c407b256f0f83ee011f83d42b0ec405ca58->enter($__internal_2d431b4aa906ffd611b197fa06623c407b256f0f83ee011f83d42b0ec405ca58_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_2d431b4aa906ffd611b197fa06623c407b256f0f83ee011f83d42b0ec405ca58->leave($__internal_2d431b4aa906ffd611b197fa06623c407b256f0f83ee011f83d42b0ec405ca58_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_6ad0a4c216a63219eca36afe30d968be7807831856a7d9b3ec852c0fba5f8fbc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6ad0a4c216a63219eca36afe30d968be7807831856a7d9b3ec852c0fba5f8fbc->enter($__internal_6ad0a4c216a63219eca36afe30d968be7807831856a7d9b3ec852c0fba5f8fbc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_6ad0a4c216a63219eca36afe30d968be7807831856a7d9b3ec852c0fba5f8fbc->leave($__internal_6ad0a4c216a63219eca36afe30d968be7807831856a7d9b3ec852c0fba5f8fbc_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_952db72407f85ebbf6a890b39b1dfb3a8f4dee3cec811904a8ae894f7d016646 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_952db72407f85ebbf6a890b39b1dfb3a8f4dee3cec811904a8ae894f7d016646->enter($__internal_952db72407f85ebbf6a890b39b1dfb3a8f4dee3cec811904a8ae894f7d016646_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_952db72407f85ebbf6a890b39b1dfb3a8f4dee3cec811904a8ae894f7d016646->leave($__internal_952db72407f85ebbf6a890b39b1dfb3a8f4dee3cec811904a8ae894f7d016646_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
