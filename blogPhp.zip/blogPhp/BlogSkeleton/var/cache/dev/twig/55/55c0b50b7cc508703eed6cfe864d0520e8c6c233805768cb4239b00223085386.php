<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_20ba67128759431b37414262c967ae7418ecad1355f9940db575e40e7389d7b4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8804f5f88d8b4a0b78ba85ce501bfa86cd97e3b3b7b3341603e9a63a588b7ecf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8804f5f88d8b4a0b78ba85ce501bfa86cd97e3b3b7b3341603e9a63a588b7ecf->enter($__internal_8804f5f88d8b4a0b78ba85ce501bfa86cd97e3b3b7b3341603e9a63a588b7ecf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8804f5f88d8b4a0b78ba85ce501bfa86cd97e3b3b7b3341603e9a63a588b7ecf->leave($__internal_8804f5f88d8b4a0b78ba85ce501bfa86cd97e3b3b7b3341603e9a63a588b7ecf_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_353593d520720a5ce997bb73599c404bb56ebfafacf55398c618d02f966c3592 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_353593d520720a5ce997bb73599c404bb56ebfafacf55398c618d02f966c3592->enter($__internal_353593d520720a5ce997bb73599c404bb56ebfafacf55398c618d02f966c3592_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_353593d520720a5ce997bb73599c404bb56ebfafacf55398c618d02f966c3592->leave($__internal_353593d520720a5ce997bb73599c404bb56ebfafacf55398c618d02f966c3592_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_1eadd64c1d5e6b25927068136344bf21b867817c96b0e4df5cede6d34d8e74c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1eadd64c1d5e6b25927068136344bf21b867817c96b0e4df5cede6d34d8e74c8->enter($__internal_1eadd64c1d5e6b25927068136344bf21b867817c96b0e4df5cede6d34d8e74c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_1eadd64c1d5e6b25927068136344bf21b867817c96b0e4df5cede6d34d8e74c8->leave($__internal_1eadd64c1d5e6b25927068136344bf21b867817c96b0e4df5cede6d34d8e74c8_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_486775017e67ea76e18b638229320981b0f87e0ef2e3a3370d7189201a254aba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_486775017e67ea76e18b638229320981b0f87e0ef2e3a3370d7189201a254aba->enter($__internal_486775017e67ea76e18b638229320981b0f87e0ef2e3a3370d7189201a254aba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_486775017e67ea76e18b638229320981b0f87e0ef2e3a3370d7189201a254aba->leave($__internal_486775017e67ea76e18b638229320981b0f87e0ef2e3a3370d7189201a254aba_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
